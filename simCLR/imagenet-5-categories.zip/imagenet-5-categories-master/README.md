# imagenet-5-categories
This repository contains images from 5 categories (250 for train and 50 for test for each category)

I prepared this dataset using https://github.com/mf1024/ImageNet-Datasets-Downloader and I manually selected 300 images from each category.

The categories are: airplane, car, cat, dog and elephant.
